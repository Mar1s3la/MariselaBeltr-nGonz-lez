require 'rubygems'
require 'bundler/setup'


require 'awesome_print'
require 'pry'
require 'sqlite3'

require './sqlite/sqlite_script'
require './ap/permissions'
require './pry/propina_script'

admin_personal_info = {'name'=>'Marisela', 'last_name'=>'Beltran', 'birth_year'=>'1994'}
admin_contact_info ={'email'=>'maryutng24redes@gmail.com', 'mob'=>'4181835060'}
admin_role = Role.new('users','contacts', 'promotions')
admin = User.new(admin_personal_info, admin_contact_info, admin_role)

ap admin_personal_info
ap admin_contact_info
ap admin_role.permissions

ap admin_role.methods - Object.methods

puts tip(80)

save_new_user('Joel Beltran', 'jbelgon_1999@hotmail.com','1999')
users = save_new_user('Alfonso Beltran', 'alfonsobel@gmail.com','1997')
ap users

