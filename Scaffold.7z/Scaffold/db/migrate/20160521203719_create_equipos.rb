class CreateEquipos < ActiveRecord::Migration
  def change
    create_table :equipos do |t|
      t.string :nombre
      t.string :sobrenombre
      t.integer :anio_fundacion
      t.string :liga
      t.string :pais
      t.string :dt

      t.timestamps null: false
    end
  end
end
