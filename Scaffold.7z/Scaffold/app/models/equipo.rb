class Equipo < ActiveRecord::Base
end
