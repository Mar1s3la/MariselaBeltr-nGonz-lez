class CreateClientes < ActiveRecord::Migration
  def change
    create_table :clientes do |t|
      t.string :nombre_cliente
      t.string :ap_paterno
      t.string :ap_materno
      t.string :calle
      t.string :numero
      t.string :colonia
      t.string :municipio
      t.string :estado
      t.string :pais
      t.string :telefono
      t.string :celular
      t.string :email

      t.timestamps null: false
    end
  end
end
