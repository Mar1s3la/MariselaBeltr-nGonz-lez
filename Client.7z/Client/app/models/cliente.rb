class Cliente < ActiveRecord::Base
end
