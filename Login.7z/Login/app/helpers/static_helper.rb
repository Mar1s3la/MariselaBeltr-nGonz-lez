module StaticHelper
end
