class Person
  # Constructor
  def initialize(name)

  end

  # Redefinición del método new para enviar nil
  # en caso de que el nombre esté vacío.
  def self.new(name)
    return nil if name.empty?
    super
  end

end